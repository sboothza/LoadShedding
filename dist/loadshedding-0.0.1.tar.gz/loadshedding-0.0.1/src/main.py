import argparse
import copy
import datetime
import os.path
import re
import urllib
from pathlib import Path
from typing import Optional, List

import dateutil.parser
import requests
import tabula
import collections

import eskom_config
from classes import StageImplementation, AreaScheduleMap, ZoneStageByDay, ZoneStageMap, stage_sort
from extensions import Lst

collections.Callable = collections.abc.Callable

from bs4 import BeautifulSoup

from schedule_config import area_schedule
from serializer import serializer_instance

schedules: List[StageImplementation] = []


def get_fullname(path: str) -> str:
    p = Path(path)
    p.resolve()
    return str(p.expanduser())


def replace_all(text: str, search: str, replace: str) -> str:
    while text.find(search) > -1:
        text = text.replace(search, replace)
    return text


def get_line(text: str):
    pos = text.find("\n")
    if pos > -1:
        line = text[:pos].strip()
        text = text[pos + 1:]
        return line, text
    return "", text


def find_line(text: str, match: str):
    line = "xxxxxxxxxxxxxx"
    while not line.startswith(match):
        if text == "":
            return False, text
        line, text = get_line(text)
    return True, text


zones = ZoneStageMap()


def process_zones(schedule_map: AreaScheduleMap):
    start_day = 0
    max_day = 0

    if schedule_map.day_group == "1-16,17-31":
        start_day = 1
        max_day = 17
    elif schedule_map.day_group == "1-8,17-24":
        start_day = 1
        max_day = 9
    elif schedule_map.day_group == "9-16,25-31":
        start_day = 9
        max_day = 17

    for day in range(start_day, max_day):
        all_zones: str = schedule_map.zone_list[day - start_day]
        zone_list = [int(x) for x in re.split(r"\W+", all_zones)]
        zone_stage = ZoneStageByDay(schedule_map.stage, schedule_map.start_time, schedule_map.end_time, zone_list)
        zones.add_zone_stage(day, zone_stage)
        zones.add_zone_stage(day + 16, zone_stage)


def process_schedule():
    temp_schedules = []
    for area_schedule_item in area_schedule:
        stage = int(area_schedule_item['Stage'])
        date_range = area_schedule_item['Dates']
        regex = r"(\d+:\d{2}) (\d+:\d{2})"

        for zone in area_schedule_item['Zones']:
            matches = re.search(regex, zone[0])

            if matches:
                zone_range = [i.strip() for i in zone[1:]]
                area_schedule_map = AreaScheduleMap(stage, date_range,
                                                    dateutil.parser.parse(matches.group(1),
                                                                          default=datetime.datetime.min),
                                                    dateutil.parser.parse(matches.group(2),
                                                                          default=datetime.datetime.min),
                                                    zone_range)
                temp_schedules.append(area_schedule_map)

            else:
                print("Error!")
                exit(0)

    for sc in temp_schedules:
        process_zones(sc)


def download_file(url: str, filename: str):
    urllib.request.urlretrieve(url, filename)


def isNaN(num):
    return num != num


def process_raw_row(row, max_zones):
    new_row = []
    first = None
    for value in row:
        if isNaN(value):
            pass
        elif re.search(r"(\d+:\d{2}) (\d+:\d{2})", value):
            new_row.append(value)
        elif re.search(r"(\d+:\d{2})", value):
            if first is None:
                first = value
            else:
                new_row.append("{} {}".format(first, value))
                first = None
        else:
            z = re.split(r"\W+", value)
            while len(z) > 0:
                new_value = ",".join(z[0:max_zones])
                new_row.append(new_value)
                z = z[max_zones:]
    return new_row


def process_stage_1_2(values, schedule):
    stage = {'Stage': '1', 'Dates': '1-16,17-31', 'Zones': []}
    for row in range(4, 16):
        stage["Zones"].append(process_raw_row(values[row], 1))

    schedule.append(stage)
    stage = {'Stage': '2', 'Dates': '1-16,17-31', 'Zones': []}
    for row in range(21, 33):
        stage["Zones"].append(process_raw_row(values[row], 2))
    schedule.append(stage)


def process_stage_3_4(values, schedule):
    stage = {'Stage': '3', 'Dates': '1-16,17-31', 'Zones': []}
    for row in range(4, 16):
        stage["Zones"].append(process_raw_row(values[row], 3))

    schedule.append(stage)
    stage = {'Stage': '4', 'Dates': '1-16,17-31', 'Zones': []}
    for row in range(21, 33):
        stage["Zones"].append(process_raw_row(values[row], 4))
    schedule.append(stage)


def process_stage_5(values, schedule):
    stage = {'Stage': '5', 'Dates': '1-8,17-24', 'Zones': []}
    for row in range(4, 16):
        stage["Zones"].append(process_raw_row(values[row], 5))

    schedule.append(stage)
    stage = {'Stage': '5', 'Dates': '9-16,25-31', 'Zones': []}
    for row in range(20, 32):
        stage["Zones"].append(process_raw_row(values[row], 5))
    schedule.append(stage)


def process_stage_6(values, schedule):
    stage = {'Stage': '6', 'Dates': '1-8,17-24', 'Zones': []}
    for row in range(4, 16):
        stage["Zones"].append(process_raw_row(values[row], 6))

    schedule.append(stage)
    stage = {'Stage': '6', 'Dates': '9-16,25-31', 'Zones': []}
    for row in range(20, 32):
        stage["Zones"].append(process_raw_row(values[row], 6))
    schedule.append(stage)


def process_stage_7(values, schedule):
    stage = {'Stage': '7', 'Dates': '1-8,17-24', 'Zones': []}
    for row in range(4, 16):
        stage["Zones"].append(process_raw_row(values[row], 7))

    schedule.append(stage)
    stage = {'Stage': '7', 'Dates': '9-16,25-31', 'Zones': []}
    for row in range(20, 32):
        stage["Zones"].append(process_raw_row(values[row], 7))
    schedule.append(stage)


def process_stage_8_1(values, schedule):
    stage = {'Stage': '8', 'Dates': '1-8,17-24', 'Zones': []}
    for row in range(2, 14):
        stage["Zones"].append(process_raw_row(values[row], 8))

    schedule.append(stage)


def process_stage_8_2(values, schedule):
    stage = {'Stage': '8', 'Dates': '9-16,25-31', 'Zones': []}
    for row in range(2, 14):
        stage["Zones"].append(process_raw_row(values[row], 8))

    if len(stage["Zones"][11]) == 8:
        # stuffing thing misses the last cell...
        temp = stage["Zones"][11][7]
        stage["Zones"][11].append(temp)
    schedule.append(stage)


def download_table():
    url = "https://www.capetown.gov.za/Loadshedding1/loadshedding/Load_Shedding_All_Areas_Schedule_and_Map.pdf"

    path = os.path.join(os.getcwd(), "Load_Shedding_All_Areas_Schedule_and_Map.pdf")
    path = get_fullname(path)
    if not os.path.exists(path):
        download_file(url, path)

    new_schedule = []
    tables = tabula.read_pdf(path, pages="2", multiple_tables=True, guess=False)
    process_stage_1_2(tables[0].values, new_schedule)
    tables = tabula.read_pdf(path, pages="3", multiple_tables=True, guess=False)
    process_stage_3_4(tables[0].values, new_schedule)
    tables = tabula.read_pdf(path, pages="4", multiple_tables=True, guess=False)
    process_stage_5(tables[0].values, new_schedule)
    tables = tabula.read_pdf(path, pages="5", multiple_tables=True, guess=False)
    process_stage_6(tables[0].values, new_schedule)
    tables = tabula.read_pdf(path, pages="6", multiple_tables=True, guess=False)
    process_stage_7(tables[0].values, new_schedule)
    tables = tabula.read_pdf(path, pages="7", multiple_tables=True, guess=False)
    process_stage_8_1(tables[0].values, new_schedule)
    process_stage_8_2(tables[1].values, new_schedule)

    text = serializer_instance.serialize(new_schedule)
    path = os.path.join(os.getcwd(), "src", "schedule_config.py")
    with open(path, 'w') as output_file:
        output_file.write("area_schedule = " + text)
        output_file.flush()


def load_schedule_from_web():
    page = requests.get(
        "https://www.capetown.gov.za/Family%20and%20home/Residential-utility-services/Residential-electricity-services/Load-shedding-and-outages")
    soup = BeautifulSoup(page.content, "html5lib")
    tags = soup.find_all("div", class_="section-pull")
    text = tags[0].text
    text = replace_all(text, "\r", "")
    text = replace_all(text, "\t", "")
    text = replace_all(text, "\n\n", "\n")
    text = match_header(text)
    text = match_dates(text)


def split_schedules():
    global schedules
    new_schedules: List[StageImplementation] = []
    for schedule in schedules:
        if schedule.end_time.day == schedule.start_time.day:
            new_schedules.append(schedule)
        else:
            # multiple days
            day: int = schedule.start_time.day
            new_start_date = schedule.start_time
            new_end_date = datetime.datetime.combine(schedule.start_time, datetime.time.max)
            while True:
                s = StageImplementation(schedule.number, new_start_date, new_end_date)
                new_schedules.append(s)
                day = day + 1
                new_start_date = new_start_date.replace(day=day, hour=0, minute=0, second=0, microsecond=0)
                if new_start_date > schedule.end_time:
                    break

                new_end_date = new_end_date.replace(day=day)
                if new_end_date > schedule.end_time:
                    new_end_date = schedule.end_time

            # new_start_date = datetime.datetime.combine(schedule.end_time, datetime.time.min)
            # new_end_date = datetime.datetime.combine(schedule.start_time, datetime.time.max)
            # s1 = StageImplementation(schedule.number, schedule.start_time, new_end_date)
            # s2 = StageImplementation(schedule.number, new_start_date, schedule.end_time)
            # new_schedules.append(s1)
            # new_schedules.append(s2)

    schedules = new_schedules


def merge_stages(stages: List[StageImplementation]):
    if len(stages) < 2:
        return stages

    cleaned_stages: Lst[StageImplementation] = Lst(stages)

    i: int = 0
    while i < len(cleaned_stages) - 1:
        stage1 = cleaned_stages[i]
        stage2 = cleaned_stages[i + 1]
        if stage2.start_time <= stage1.end_time:
            new_stage: StageImplementation = copy.deepcopy(stage1)
            new_stage.end_time = stage2.end_time
            cleaned_stages.remove(stage1)
            cleaned_stages.remove(stage2)
            cleaned_stages.insert(i, new_stage)
        else:
            i = i + 1

    return cleaned_stages


# compare next if there is one


def main():
    global schedules
    parser = argparse.ArgumentParser(description="Download videos from streaming source")
    parser.add_argument('--zone',
                        help='zone',
                        dest='zone',
                        type=int,
                        default=0,
                        required=False)
    parser.add_argument('--update-tables',
                        help='Update zone tables',
                        dest='update',
                        action='store_true',
                        default=False,
                        required=False)
    parser.add_argument('--use-eskom',
                        help='Use Eskom schedule',
                        dest='eskom',
                        action='store_true',
                        default=False,
                        required=False)

    args = parser.parse_args()

    if args.update:
        download_table()
        exit(0)

    if args.zone == 0:
        print('Zone is required')
        parser.print_help()
        exit(1)

    process_schedule()
    my_zone = int(args.zone)
    time_now = datetime.datetime.today()

    if args.eskom:
        schedules = serializer_instance.remap(eskom_config.eskom_schedules)
    else:
        load_schedule_from_web()

    split_schedules()
    # find times for zone from start time to end time

    active_schedules = [s for s in schedules if time_now <= s.end_time]

    new_stages = []
    for schedule in active_schedules:
        # find zone schedule that falls in this schedule
        stages_for_today = zones.get_for_day_and_zone(schedule.end_time.day, my_zone, schedule.start_time.date())

        for s in stages_for_today:
            if s.number == schedule.number and schedule.start_time <= s.start_time and schedule.end_time >= s.end_time:
                # check for existing
                existing = [x for x in new_stages if x.start_time == s.start_time and x.end_time == s.end_time]
                if len(existing) == 0:
                    new_stages.append(s)

    new_stages = merge_stages(new_stages)

    print("Current loadshedding status for zone {}".format(my_zone))
    new_stages.sort(key=stage_sort)
    current_date = datetime.datetime.min
    for s in new_stages:
        d = s.start_time.date()
        if d != current_date:
            print("{:%A, %B %d}".format(d))
            current_date = d
        print(s.disp())


def match_header(text):
    res, text = find_line(text, "Load-shedding")
    if not res:
        print("fail")
        exit(0)
    res, text = find_line(text, "City customers:")
    if not res:
        print("fail")
        exit(0)
    return text


def parse_stage(line, stage_date) -> Optional[StageImplementation]:
    regex = r"Stage (\d+): (\d{2}:\d{2}) - (\d{2}:\d{2})"
    matches = re.search(regex, line)

    if matches:
        stage = StageImplementation()
        stage.number = int(matches.group(1))
        stage.start_time = dateutil.parser.parse(matches.group(2), default=stage_date)
        stage.end_time = dateutil.parser.parse(matches.group(3), default=stage_date)
        if stage.end_time < stage.start_time:
            stage.end_time = stage.end_time + datetime.timedelta(days=1)
        return stage

    return None


def match_dates(text):
    global schedules

    state = "date"  # stage, other
    line, text = get_line(text)
    date = datetime.datetime.min
    while state != "other":
        if state == "date":
            try:
                date = dateutil.parser.parse(line)
                state = "stage"
                line, text = get_line(text)
            except:
                if line.startswith("Stage"):
                    state = "stage"
                else:
                    state = "other"
        elif state == "stage":
            if line.startswith("Stage"):
                stage = parse_stage(line, date)
                schedules.append(stage)
                line, text = get_line(text)
            else:
                state = "date"

    return text


if __name__ == '__main__':
    main()
