import datetime

from extensions import get_date
from serializer import serializer_instance


class StageImplementation:
    def __init__(self, stage: int = 0, start_time: datetime.datetime = datetime.datetime.min,
                 end_time: datetime.datetime = datetime.datetime.min):
        self.number: int = stage
        self.start_time: datetime.datetime = start_time
        self.end_time: datetime.datetime = end_time
        # if self.end_time < self.start_time:
        #     self.end_time = self.end_time + datetime.timedelta(days=1)

    def __str__(self):
        return "Stage:{} from:{} to {}".format(self.number, self.start_time, self.end_time)

    def load(self, obj, serializer):
        self.number = int(obj["number"])
        self.start_time = get_date(obj["start_time"])
        self.end_time = get_date(obj["end_time"])
        # if self.end_time < self.start_time:
        #     self.end_time = self.end_time + datetime.timedelta(days=1)

    def disp(self):
        return "{:%H:%M} to {:%H:%M} : Stage {}".format(self.start_time, self.end_time, self.number)


def stage_sort(s):
    return s.start_time


serializer_instance.register(StageImplementation())


class AreaScheduleMap:
    def __init__(self, stage: int = 0, day_group: str = '', start_time: datetime.datetime = datetime.datetime.min,
                 end_time: datetime.datetime = datetime.datetime.min, zone_list=None):
        if zone_list is None:
            zone_list = []
        self.stage: int = stage
        self.day_group: str = day_group
        self.start_time: datetime.datetime = start_time
        self.end_time: datetime.datetime = end_time
        self.zone_list = zone_list

    def __str__(self):
        return "Stage:{} day_group:{} start:{} end:{} zones:{}".format(self.stage, self.day_group, self.start_time,
                                                                       self.end_time, self.zone_list)


serializer_instance.register(AreaScheduleMap())


class ZoneStageByDay:
    def __init__(self, stage: int = 0, start_time: datetime.datetime = datetime.datetime.min,
                 end_time: datetime.datetime = datetime.datetime.min, zone_list=None):
        self.stage = stage
        if zone_list is None:
            zone_list = []
        self.start_time = start_time
        self.end_time = end_time
        self.zone_list = zone_list

    def __str__(self):
        return "stage:{} start:{} end:{} zones:[{}]".format(self.stage, self.start_time, self.end_time,
                                                            ",".join([str(z) for z in self.zone_list]))


serializer_instance.register(ZoneStageByDay())


class ZoneStageMap:
    def __init__(self):
        self.stage_by_day = {}

    def add_zone_stage(self, day: int, zone: ZoneStageByDay):
        stages = None
        if day not in self.stage_by_day:
            stages = []
        else:
            stages = self.stage_by_day[day]

        stages.append(zone)
        self.stage_by_day[day] = stages

    def get_for_day_and_zone(self, day: int, zone: int, for_date: datetime.datetime):
        day_schedules = self.stage_by_day[day]
        new_list = [StageImplementation(zs.stage, datetime.datetime.combine(for_date, zs.start_time.time()),
                                        datetime.datetime.combine(for_date, zs.end_time.time())) for zs in day_schedules
                    if zone in zs.zone_list]
        return new_list


serializer_instance.register(ZoneStageMap())
